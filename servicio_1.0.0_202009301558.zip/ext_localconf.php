<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Pablo.Servicio',
            'Servicio',
            [
                'Servicio' => 'list, show, new, create, edit, update, delete, search, generateExcel, generateCSV'
            ],
            // non-cacheable actions
            [
                'Servicio' => 'list, show, new, create, edit, update, delete, search, generateExcel, generateCSV'
            ]
        );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    servicio {
                        icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('servicio') . 'Resources/Public/Icons/user_plugin_servicio.svg
                        title = LLL:EXT:servicio/Resources/Private/Language/locallang_db.xlf:tx_servicio_domain_model_servicio
                        description = LLL:EXT:servicio/Resources/Private/Language/locallang_db.xlf:tx_servicio_domain_model_servicio.description
                        tt_content_defValues {
                            CType = list
                            list_type = servicio_servicio
                        }
                    }
                }
                show = *
            }
       }'
    );
    }
);

$GLOBALS['TYPO3_CONF_VARS']['FE']['eID_include']['servicio_servicio'] = 'EXT:servicio/Classes/EID/ServicioEID.php';
