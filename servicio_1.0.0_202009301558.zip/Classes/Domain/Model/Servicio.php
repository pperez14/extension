<?php
namespace Pablo\Servicio\Domain\Model;

/***
 *
 * This file is part of the "EjemploServicio" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020
 *
 ***/

/**
 * Servicio
 */
class Servicio extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * nombre
     *
     * @var string
     */
    protected $nombre = '';

    /**
     * costo
     *
     * @var string
     */
    protected $costo = '';

    /**
     * disponibilidad
     *
     * @var string
     */
    protected $disponibilidad = '';

    /**
     * Returns the nombre
     *
     * @return string $nombre
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Sets the nombre
     *
     * @param string $nombre
     * @return void
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    /**
     * Returns the costo
     *
     * @return string $costo
     */
    public function getCosto()
    {
        return $this->costo;
    }

    /**
     * Sets the costo
     *
     * @param string $costo
     * @return void
     */
    public function setCosto($costo)
    {
        $this->costo = $costo;
    }

    /**
     * Returns the disponibilidad
     *
     * @return string $disponibilidad
     */
    public function getDisponibilidad()
    {
        return $this->disponibilidad;
    }

    /**
     * Sets the disponibilidad
     *
     * @param string $disponibilidad
     * @return void
     */
    public function setDisponibilidad($disponibilidad)
    {
        $this->disponibilidad = $disponibilidad;
    }
}
