
plugin.tx_servicio_servicio {
    view {
        # cat=plugin.tx_servicio_servicio/file; type=string; label=Path to template root (FE)
        templateRootPath = EXT:servicio/Resources/Private/Templates/
        # cat=plugin.tx_servicio_servicio/file; type=string; label=Path to template partials (FE)
        partialRootPath = EXT:servicio/Resources/Private/Partials/
        # cat=plugin.tx_servicio_servicio/file; type=string; label=Path to template layouts (FE)
        layoutRootPath = EXT:servicio/Resources/Private/Layouts/
    }
    persistence {
        # cat=plugin.tx_servicio_servicio//a; type=string; label=Default storage PID
        storagePid =
    }
}
