<?php
namespace Pablo\Servicio\Tests\Unit\Domain\Model;

/**
 * Test case.
 */
class ServicioTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Pablo\Servicio\Domain\Model\Servicio
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Pablo\Servicio\Domain\Model\Servicio();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getNombreReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getNombre()
        );
    }

    /**
     * @test
     */
    public function setNombreForStringSetsNombre()
    {
        $this->subject->setNombre('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'nombre',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getCostoReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getCosto()
        );
    }

    /**
     * @test
     */
    public function setCostoForStringSetsCosto()
    {
        $this->subject->setCosto('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'costo',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getDisponibilidadReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getDisponibilidad()
        );
    }

    /**
     * @test
     */
    public function setDisponibilidadForStringSetsDisponibilidad()
    {
        $this->subject->setDisponibilidad('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'disponibilidad',
            $this->subject
        );
    }
}
