<?php
namespace Pablo\Servicio\Tests\Unit\Controller;

/**
 * Test case.
 */
class ServicioControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Pablo\Servicio\Controller\ServicioController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Pablo\Servicio\Controller\ServicioController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllServiciosFromRepositoryAndAssignsThemToView()
    {

        $allServicios = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $servicioRepository = $this->getMockBuilder(\Pablo\Servicio\Domain\Repository\ServicioRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $servicioRepository->expects(self::once())->method('findAll')->will(self::returnValue($allServicios));
        $this->inject($this->subject, 'servicioRepository', $servicioRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('servicios', $allServicios);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function showActionAssignsTheGivenServicioToView()
    {
        $servicio = new \Pablo\Servicio\Domain\Model\Servicio();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('servicio', $servicio);

        $this->subject->showAction($servicio);
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenServicioToServicioRepository()
    {
        $servicio = new \Pablo\Servicio\Domain\Model\Servicio();

        $servicioRepository = $this->getMockBuilder(\Pablo\Servicio\Domain\Repository\ServicioRepository::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $servicioRepository->expects(self::once())->method('add')->with($servicio);
        $this->inject($this->subject, 'servicioRepository', $servicioRepository);

        $this->subject->createAction($servicio);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenServicioToView()
    {
        $servicio = new \Pablo\Servicio\Domain\Model\Servicio();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('servicio', $servicio);

        $this->subject->editAction($servicio);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenServicioInServicioRepository()
    {
        $servicio = new \Pablo\Servicio\Domain\Model\Servicio();

        $servicioRepository = $this->getMockBuilder(\Pablo\Servicio\Domain\Repository\ServicioRepository::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $servicioRepository->expects(self::once())->method('update')->with($servicio);
        $this->inject($this->subject, 'servicioRepository', $servicioRepository);

        $this->subject->updateAction($servicio);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenServicioFromServicioRepository()
    {
        $servicio = new \Pablo\Servicio\Domain\Model\Servicio();

        $servicioRepository = $this->getMockBuilder(\Pablo\Servicio\Domain\Repository\ServicioRepository::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $servicioRepository->expects(self::once())->method('remove')->with($servicio);
        $this->inject($this->subject, 'servicioRepository', $servicioRepository);

        $this->subject->deleteAction($servicio);
    }
}
